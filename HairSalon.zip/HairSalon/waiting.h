#pragma once

#include <string>

using namespace std;

class Waiting {
public:
	string customerName;
	string service;
};